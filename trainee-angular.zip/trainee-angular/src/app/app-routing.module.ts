import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ListTraineeComponent } from './list-trainee/list-trainee.component';
import { UpdateTraineeComponent } from './update-trainee/update-trainee.component';
import { AddTraineeComponent } from './add-trainee/add-trainee.component';


const routes: Routes = [{path:'listtrainee',component:ListTraineeComponent},
{path:'addtrainee',component:AddTraineeComponent},
{path:'updatetrainee',component:UpdateTraineeComponent}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
