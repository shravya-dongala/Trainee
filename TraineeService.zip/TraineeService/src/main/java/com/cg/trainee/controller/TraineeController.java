package com.cg.trainee.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.trainee.dto.Trainee;
import com.cg.trainee.service.TraineeService;
@RestController
//@CrossOrigin("http://localhost:4200")
public class TraineeController 
{
	@Autowired
	TraineeService traineeService;
	public void setTraineeService(TraineeService traineeService)
	{
		this.traineeService=traineeService;
	}
	
   @GetMapping("/getTrainee/{traineeId}")
   public Trainee getTrainee(@PathVariable int traineeId)
   {
	   return traineeService.getTrainee(traineeId);
   }
   
  
   @GetMapping("/getTrainees")
   public List<Trainee> getTrainees()
   {
	   return traineeService.getTrainees();
   }

   @PostMapping(value="/addTrainee",consumes="application/json")
   public ResponseEntity<String> insertTrainee(@RequestBody()Trainee trainee)
   {
	   String message="Trainee Inserted Successfully";
	   if(traineeService.insertTrainee(trainee)==null)
		   message="Trainee Insertion Failed";
	   return new ResponseEntity<String>(message,HttpStatus.BAD_REQUEST);
   }
   
   @PutMapping(value="/updateTrainee",consumes="application/json")
   public String updateTrainee(@RequestBody()Trainee trainee)
   {
	   String message=traineeService.updateTrainee(trainee);
	   return message;
   }
   
   @DeleteMapping("/deleteTrainee/{traineeId}")
   public String deleteTrainee(@PathVariable int traineeId)
   {
	   return traineeService.deleteTrainee(traineeId); 
   }
}
