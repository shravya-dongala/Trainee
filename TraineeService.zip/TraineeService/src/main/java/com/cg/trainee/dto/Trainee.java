package com.cg.trainee.dto;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class Trainee 
{
	@Id
	@Column(name="traineeid")
	int traineeId;
	@Column(name="name")
	String name;
	@Column(name="domain")
	String domain;
	@Column(name="location")
	String location;
	public Trainee() {	}
	public Trainee(int traineeId, String name, String domain, String location) 
	{
		this.traineeId = traineeId;
		this.name = name;
		this.domain = domain;
		this.location = location;
	}
	public int getTraineeId() {
		return traineeId;
	}
	public void setTraineeId(int traineeId) {
		this.traineeId = traineeId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDomain() {
		return domain;
	}
	public void setDomain(String domain) {
		this.domain = domain;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	
}
