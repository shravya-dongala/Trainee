package com.cg.trainee.service;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.cg.trainee.dao.TraineeDao;
import com.cg.trainee.dto.Trainee;
@Service
public class TraineeService 
{
	@Autowired
    TraineeDao tdao;
    public void setTdao(TraineeDao tdao) { this.tdao=tdao;}
    @Transactional
    public Trainee insertTrainee(Trainee trainee)
    {
        return tdao.save(trainee);
    }
    @Transactional(readOnly=true)
    public Trainee getTrainee(int traineeId)
    {
    	return tdao.findById(traineeId).get();
    }
    @Transactional(readOnly=true)
    public List<Trainee> getTrainees()
    {
    	return tdao.findAll();
    }
    @Transactional
    public String deleteTrainee(int traineeId)
    {
    	tdao.deleteById(traineeId);
    	return "Trainee Deleted";
    }
    
    @Transactional
    public String updateTrainee(Trainee newTrainee)
    {
    	Trainee trainee= tdao.findById(newTrainee.getTraineeId()).get();
    	if(trainee!=null)
    	{
    	  trainee.setName(newTrainee.getName());
    	  trainee.setDomain(newTrainee.getDomain());
    	  trainee.setLocation(newTrainee.getLocation());
    	  return "Trainee Modified";
    	}
    	return "Update Failed";
    }
}
