package com.cg.trainee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TraineeServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(TraineeServiceApplication.class, args);
	}

}
